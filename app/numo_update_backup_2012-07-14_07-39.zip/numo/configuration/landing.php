<!--<div>
<h2>Welcome  <?php echo $_SESSION['full_name']; ?>!</h2>
<p>Your server timezone is currently set to <?php echo date("e"); ?>.</p>
</div>
-->