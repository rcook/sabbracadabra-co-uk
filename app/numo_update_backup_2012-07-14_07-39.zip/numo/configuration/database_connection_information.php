<?php
define(DATABASE_HOST, 'localhost');
define(DATABASE_NAME, 'jonkershawmusic_com');
define(DATABASE_USERNAME, 'jkershaw');
define(DATABASE_PASSWORD, 'jkershaw');
define(NUMO_SITE_ID, '1');
define(NUMO_SERVER_ADDRESS, 'www.jonkershawmusic.com');
define(NUMO_FOLDER_PATH, '/numo/');
define(NUMO_SECURE_ADDRESS,  'www.jonkershawmusic.com');
define(NUMO_SECURE_BACKEND,   false);
define(NUMO_SECURE_FRONTEND,  false);
define(USE_INTERNAL_SESSIONS, false);
?>