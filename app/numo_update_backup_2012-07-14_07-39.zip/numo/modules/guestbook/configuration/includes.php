<?php
include(MODULES_FOLDER_NAME.'/'.$moduleFolderName.'/classes/Guestbook.php');
?>