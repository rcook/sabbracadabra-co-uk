<?php
include(MODULES_FOLDER_NAME.'/'.$moduleFolderName.'/classes/Product.php');
?>