<h2>Manage Settings</h2>
<p>Please choose from one of the following settings options</p>
<div class="settings-option-box">
<h2>Language Syntax</h2>
<p>Change any configurable syntax element here.</p>
<form method="get" action="module/<?=$_GET['m']?>/manage-syntax/">
<input type='submit' value='Edit' />
</form>
</div>

<div class="settings-option-box">
<h2>SSL Security</h2>
<p>Change how your site is secured via SSL.<br/>&nbsp;</p>
<form method="get" action="module/<?=$_GET['m']?>/manage-ssl-security/">
<input type='submit' value='Edit' />
</form>
</div>
