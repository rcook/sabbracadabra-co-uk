<?php
global $SYSTEM_ERROR_ID;
print constant('NUMO_SYNTAX_'.$SYSTEM_ERROR_ID);
?>