<?php
print constant('NUMO_SYNTAX_'.$PARAMS['id']);
?>