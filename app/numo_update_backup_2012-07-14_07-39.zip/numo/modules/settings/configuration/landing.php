<div class="module_install_settings">
<img class='icon' src="images/configuration.png" />
<a href="http://www.i3dthemes.com/support/numo_settings/" target="_blank"><img alt='Help' title='Help' class='help-icon' src="images/help.png" /></a>

<h2>System Settings</h2>
<hr />
<p>Your server timezone is currently set to <?php echo date("e"); ?>.</p>
<!--<p>Instruction: <a href="http://www.luckymarble.com/members/product/helpsys/numo/numo_settings_guide.pdf">View Manual</a></p>-->
<!--<hr />-->
</div>
<br/>