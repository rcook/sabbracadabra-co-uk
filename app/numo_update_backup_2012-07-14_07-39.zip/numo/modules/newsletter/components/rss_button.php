<?php
$link = "http://".NUMO_SERVER_ADDRESS;

print '<a class="numo_newsletter_rss_feed_button" href="'.$link.'/manage.numo?module=newsletter&component=rss"><img src="'.NUMO_FOLDER_PATH.'modules/newsletter/images/rss.jpg" alt="RSS" title="RSS" border="0" /></a>';
?>