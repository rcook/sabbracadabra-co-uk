<?php
require(MODULES_FOLDER_NAME.'/'.$moduleFolderName.'/classes/MarbleMail.php');
?>